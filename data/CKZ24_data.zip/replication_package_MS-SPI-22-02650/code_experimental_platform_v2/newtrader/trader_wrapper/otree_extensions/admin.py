from ..views import PandasExport

data_export_views = [PandasExport]
